import os, sys, uuid
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse
from pydantic import BaseModel
from agents.agent import root_agent
from engine import tools as E
from google.adk.runners import Runner
from google.adk.sessions import InMemorySessionService
from google.genai import types

APP = "promolens"
session_service = InMemorySessionService()
runner = Runner(agent=root_agent, app_name=APP, session_service=session_service)
app = FastAPI(title="PromoLens AI")
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])

UI_PATH = os.path.join(os.path.dirname(__file__), "..", "ui", "public", "index.html")


class ChatIn(BaseModel):
    message: str
    session_id: str | None = None


def _rupees(n):
    n = float(n or 0)
    if abs(n) >= 1e7: return f"Rs {n/1e7:.2f} Cr"
    if abs(n) >= 1e5: return f"Rs {n/1e5:.1f} L"
    return f"Rs {round(n):,}"


def deterministic_answer(msg: str) -> str:
    """Plain, decision-ready answers for business users: the number + what to do."""
    m = (msg or "").lower()
    try:
        if any(k in m for k in ["leak", "sell-in", "sell out", "sell-out", "inventory", "loading", "loading inventory"]):
            rows = E.inventory_loading_leaks()
            if not rows:
                return "Good news — no signs of inventory loading right now. Distributors are selling through what they buy."
            r = rows[0]
            return (f"{r['name']} ({r['state']}) is loading inventory: buying a lot of {r['sku_code']} but only "
                    f"{r['sellthrough']*100:.0f}% is actually selling through (stock piled up: {int(r['closing'])} units). "
                    f"They're buying to claim the incentive, not because there's demand. "
                    f"→ Do this: pause further dispatch to them and verify real sell-out before paying the scheme.")
        if any(k in m for k in ["claim", "entitlement", "paying", "pay"]):
            oc = E.overclaims()
            if oc["count"] == 0:
                return "No over-claims found — what partners are claiming matches what they earned."
            top = oc["rows"][0]
            return (f"Yes — {oc['count']} claim(s) are higher than what was actually earned, {_rupees(oc['total_at_risk'])} at risk. "
                    f"Largest: {top['name']} claimed {_rupees(top['claimed_amount'])} but earned only {_rupees(top['earned'])}. "
                    f"→ Do this: block or recover {_rupees(oc['total_at_risk'])} before the next payout run.")
        if any(k in m for k in ["stack", "effective discount", "putty", "real discount"]):
            s = E.stacked_effective_discount()
            return (f"On putty, several schemes pile onto the same invoice. The real discount works out to about "
                    f"{s['avg_effective_discount_pct']}% (up to {s['max_effective_discount_pct']}%) — even though each scheme looks like ~5%. "
                    f"That extra margin leaks away without anyone deciding it. → Do this: cap the total discount allowed per invoice.")
        if any(k in m for k in ["apply", "applied", "active", "expired", "didn't apply", "not apply", "live"]):
            skips = E.why_not_applied(only_skips=True)
            states = {x["status"]: x["schemes"] for x in E.scheme_state_view()}
            if skips:
                s0 = skips[0]
                return (f"{states.get('active',0)} schemes are live, {states.get('expired',0)} expired, {states.get('draft',0)} still in draft. "
                        f"One isn't applying: {s0['scheme_id']} skipped {s0['invoices_skipped']} invoices because {s0['skip_reason']}. "
                        f"→ Do this: fix that scheme's setup so customers actually get the offer.")
            return f"{states.get('active',0)} schemes are live and applying correctly; {states.get('expired',0)} expired, {states.get('draft',0)} in draft."
        if any(k in m for k in ["sync", "master", "data trust", "mismatch", "data quality"]):
            d = E.data_trust_summary()
            reason = d["top_reasons"][0]["reason"] if d.get("top_reasons") else ""
            return (f"{d['fail_rate_pct']}% of sales records didn't sync cleanly ({d['failed']} of {d['total']}), mostly: {reason}. "
                    f"Your scheme numbers are only as reliable as this data. → Do this: clean the master data and re-sync before trusting payouts.")
        if "cannibal" in m:
            c = E.cannibalisation("BLD-PUTTY-S", "BLD-PUTTY-W")
            return (f"Pushing {c['push_sku']} ({c['push_change_pct']:+}%) is eating into {c['victim_sku']} ({c['victim_change_pct']:+}%) — "
                    f"you're partly shifting sales, not adding them. → Do this: judge the scheme on total category growth, not one SKU.")
        if any(k in m for k in ["design", "what if", "what-if", "recommend", "propose", "budget", "launch", "next"]):
            w = E.whatif_simulator("Rajasthan", ["BLD-OPC53", "BLD-PPC"], 1.75, 12)
            verdict = "worth running" if w["projected_roi"] > 1 else "marginal — tighten it first"
            return (f"For a Rajasthan OPC growth scheme (+12% target, ~1.75% payout): expected extra sales {_rupees(w['incremental_value'])}, "
                    f"cost {_rupees(w['projected_outflow'])}, so about Rs {w['projected_roi']} back per Rs 1. That's {verdict}. "
                    f"→ Do this: launch in Rajasthan; copy the design that already works there.")
        rank = E.rank_schemes_by_roi("BLD")
        if not rank:
            return "No active building-materials schemes to assess yet."
        win, dud = rank[0], rank[-1]
        body = " | ".join(f"{r['name']}: Rs {r['roi']} back per Rs 1" for r in rank[:5])
        tail = ""
        if dud["roi"] < 0.3:
            tail = (f" Your weakest is {dud['name']} — it loses money (those sales would've happened anyway). "
                    f"→ Do this: scale {win['name']}, and stop or redesign {dud['name']}.")
        return f"Best scheme: {win['name']} — earns Rs {win['roi']} for every Rs 1 spent. Ranked: {body}.{tail}"
    except Exception as e:
        return f"(could not compute right now: {e})"


@app.get("/healthz")
def healthz():
    return {"ok": True}


@app.get("/", response_class=HTMLResponse)
def home():
    try:
        with open(UI_PATH, encoding="utf-8") as f:
            return f.read()
    except Exception:
        return "<h1>PromoLens AI</h1><p>UI not found. API is at /chat.</p>"


@app.get("/api/dashboard")
def dashboard():
    out = {}
    try:
        out["schemes"] = E.rank_schemes_by_roi("BLD")
    except Exception as e:
        out["schemes"] = []
        out["schemes_error"] = str(e)
    try:
        out["leaks"] = E.inventory_loading_leaks()[:5]
    except Exception:
        out["leaks"] = []
    try:
        out["overclaims"] = E.overclaims()
    except Exception:
        out["overclaims"] = {"total_at_risk": 0, "count": 0, "rows": []}
    try:
        out["trust"] = E.data_trust_summary()
    except Exception:
        out["trust"] = {}
    try:
        out["stacking"] = E.stacked_effective_discount()
    except Exception:
        out["stacking"] = {}
    return out


@app.post("/chat")
async def chat(inp: ChatIn):
    user_id = "demo-user"
    session_id = inp.session_id or ("s-" + uuid.uuid4().hex[:8])
    answer = ""
    mode = "llm"
    try:
        await session_service.create_session(app_name=APP, user_id=user_id, session_id=session_id)
    except Exception:
        pass
    try:
        msg = types.Content(role="user", parts=[types.Part(text=inp.message)])
        async for event in runner.run_async(user_id=user_id, session_id=session_id, new_message=msg):
            if event.is_final_response() and event.content and event.content.parts:
                answer = "".join((p.text or "") for p in event.content.parts)
    except Exception:
        answer = ""
    if not answer.strip():
        answer = deterministic_answer(inp.message)
        mode = "engine"
    return {"session_id": session_id, "answer": answer, "mode": mode}
